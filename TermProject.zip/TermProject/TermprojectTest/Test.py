
import pandas as pd

df = pd.read_html("http://subway.koreatriptips.com/subway-station/SES25/SUB1514.html", flavor='html5lib')
print(len(df))
Timetable = df[1]
Timetable.to_csv("TimeB.csv")
print(Timetable)
